#include "server.hpp"
#define PORT_HOST 8000

// Constructor
serverhandel::serverhandel() {}

// Destructor
serverhandel::~serverhandel()
{
    server_close();
}

/************************** Initialization method ***********************/

bool serverhandel::server_init(void)
{

    close(client_socket_state); // to surely close any soccket

    /******************************* Variables **************** */
    //const char *address_host_ip = "192.168.1.8"; // Address for the host server
    struct sockaddr_in serverAddr;               // Structure for socket address details
    WSADATA wsaData;                             // Winsock API to hold information about the Windows Sockets

    /*************************************** Initialization *******************/

    if (WSAStartup(MAKEWORD(2, 2), &wsaData) != 0)
    {
        std::cerr << "WSAStartup failed.\n"
                  << std::endl;
    }

    /********************** Create Socket *************************/
    socket_init = socket(AF_INET, SOCK_STREAM, 0);

    // Prepare the sockaddr_in structure
    serverAddr.sin_family = AF_INET;        // IPv4
    serverAddr.sin_port = htons(PORT_HOST); // Port in network byte order ="5000"
    serverAddr.sin_addr.s_addr = INADDR_ANY;

    // Bind the socket to the address and port
    inet_pton(AF_INET, "192.168.1.6", &serverAddr.sin_addr);
    if (bind(socket_init, (struct sockaddr *)&serverAddr, sizeof(serverAddr)) == SOCKET_ERROR) {
    std::cerr << "Bind failed. Error: " << std::endl;
    return -1; // Indicate failure
} else {
    std::cout << "Socket bound successfully" << std::endl;
    return 1;
}
  
}

/***************************** listen method ******************************/

bool serverhandel::server_listen(void)
{

    if (listen(socket_init, 2) == SOCKET_ERROR)
    {
        return -1;
    }
    else
    {
        return 1;
    }
}

/**************************** accept_client method *****************************/

bool serverhandel::server_accept_client(void)
{

    struct sockaddr client_add;
    int size_of_client_add = sizeof(client_add);
    client_socket_state=accept(socket_init, (struct sockaddr *)&client_add, &size_of_client_add);
    if (client_socket_state == SOCKET_ERROR)
    {
        std::cerr << "accept failed.\n"
                  << std::endl;
        serverhandel::server_close();
        return -1;
    }
    else
    {
        std::cout << "Socket accept successfully" << std::endl;
        return 1;
    }
}

/**************************** server_recv_client_msg method *****************************/
std::string serverhandel::server_recv_client_msg()
{
    int bytes_received = recv(client_socket_state, text_recv.data(), text_recv.size(), 0);
    if (bytes_received > 0)
    {
        std::cout << "Received successfully" << std::endl;
        return std::string(text_recv.data(), bytes_received); // Create a string from the received data
    }
    return ""; // Return an empty string if there’s an error
}

/**************************** send_massage method *****************************/

bool serverhandel::server_send_msg(const std::string &message)
{
    if (send(socket_init, message.data(), sizeof(message), 0) )
    {
        return true;
    }
    return false;
}



/*************************** orgnize the text method **************************/

void serverhandel::trim_end(std::string &str)
{
    str.erase(std::find_if(str.rbegin(), str.rend(), [](unsigned char ch) { return !std::isspace(ch); }).base(),str.end());
}

/*************************** close socket method ****************************/

void serverhandel::server_close()
{
    close(socket_init);
}



